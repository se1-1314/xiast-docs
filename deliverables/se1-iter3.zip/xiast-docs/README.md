xiast-docs
==========

The SCMP contains more information about the structure and workflow of both repositories. It can be found in the `management/configuration` directory.
