$("#AddCourse").click(function() {
	$("#NewCourse").modal("show");
})

$("#AddProgram").click(function() {
	$("#NewProgram").modal("show");
})

$("#CreateProgram").click(function(){
	create_program();	
})

$("#CreateCourse").click(function(){
	create_course();
})
