Implementation leader
=====================

Kwinten Pardon
