# Agenda vergadering 10

Variabele				  |Inhoud
---			    		  |---
**Datum:**        |Donderdag 6 maart 2014
**Locatie:**      |E1.08
**Begin:**        |16u05
**Einde:**        |
**Aanwezigen:**   |
**Secretaris:**   |Nils Van Geele


# TODO-list vorige vergadering
- Meeting op IG later op donderdag om nieuwe issues aan te maken
- Anders en Youssef: nemen de tutorial van 4Clojure tegen vrijdag (= dag na vergadering!) om de nodige basiskennis m.b.t. Clojure te vergaren => API kunnen gebruiken.


# 1. Bespreking ingeleverd werk + opmerkingen Jens -> in hoeverre zijn deze in rekening gebracht (Lars, 20 min)
## Vragen & opmerkingen Jens
* Is de datadump al helemaal verteerd?
  * Ja. Draait.
* Is er al nagedacht over de scheduler?
  * Ja. Nog geen implementatie, maar wel ideeen over hoe de datastructuur er bij helpt en integratie
  * Opmerking: Iteratief inbouwen in de applicatie. Gedachtegangen en discussies erover bijhouden.
* De demo moet beter, en er moet eigenlijk gesproken worden over de demo. Focussen op het feit dat er een goede demo moet zijn die laat zien wat er allemaal afgewerkt is. Werk vanaf nu dus in functie van demo; documenten fixen, maar coderen is voornaamste zaak nu.
* Blijven coderen na deadline naar demo toe.

# 2. Bespreking: wat nog te doen voor de demo (Lars, 30 min)
Wat moet er nog allemaal gebeuren om iets werkend en functioneel te laten zien.

# 3. Presentatie Iteratie 2 (Lars, 10 min)
Wie gaat presenteren en waar moet er tijdens die presentatie op gefocust worden.


# Mededelingen
* Privégesprek met Kwinten en Adriaan


# DEADLINES:
 * **!** Dinsdag 04/03/2014 - Opleveren CODE en DOCUMENTEN **!**
 * Woensdag 12/03/2014 - Presentatie

# TODO-list

# Volgende Vergadering
Donderdag 5 maart, zelfde plaats, zelfde uur
