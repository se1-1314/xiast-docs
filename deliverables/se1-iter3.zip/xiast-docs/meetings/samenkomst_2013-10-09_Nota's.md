Nota’s samenkomt 9/10/13

* Voorstelling teamleden

* Projectnaam: nog te doen

* Wie kan wat?/doet graag wat?

    * Adriaan

        * programmeren, managen, design

        * talen:

            * alles

            * Java

            * Scheme varianten

            * C++

        * kennis van Git

    * Nils

        * liefst geen webdesign

        * graag server, data,...

        * kennis van Git

        * talen:

            * Java

            * C++

            * C

            * Racket

            * Puthon

            * Ruby

    * Kwinten

        * webdesign, webinterface (+/- ‘presentationlayer’)

        * talen

            * Scheme

            * Racket

            * Python (+ webframework)

            * C++

            * Java

            * JavaScript

    * Youssef

        * functie maakt niet al te veel uit, past zich aan

        * talen

            * Scheme

            * C++

            * wil wel graag JavaScri leren

    * Anders

        * Groepswerking, briefing/debriefing, comunicatie, coördinatie

        * heeft ruime ervaring met groepsprojecten

        * wil graag (programmeer)talen leren

        * talen

            * JavaScript

            * Modula2

        * geen kennis van Git

    * Lars

        * kan "programmeren"

        * Scheme => Racket

        * Java

        * C++

        * programmeert niet (super)graag

        * heeft bij communicatievaardigheden (voor informatici) vergaderingen geleid

* Rolverdeling

    * Projectmanager: Lars

    * Configurationmanager: Nils

    * Webmaster: Adriaan

* Communicatiestrategie

    * Vast vergadermoment: dinsdagnamiddag om 14u aan E1.08 (IG-lokaal), van daaruit gaan we naar een seminarie in het CSB

    * officieel mailadres: [se1-1314@wilma.vub.ac.be](mailto:se1-1314@wilma.vub.ac.be) (voor alle belangrijke communicatie naar voornamelijk de hele groep

    * private mail: voor details over specifiek onderwerp. Nooit gebruiken voor tijdstippen, vergaderdingen, etc.

* TODO

    * Iedereen zorgt dat hij een **Linux** (of Mac) besturingssysteem binnen ‘handbereik’ heeft en kan gerbruiken

    * Iedereen maakt een **Github account **aan en mailt zijn gebruikersnaam door naar **Nils**

    * Iedereen leest de **requirements**

    * Lars geeft de e-mailadressen van de andere groepsleden door aan Anders

