# Agenda vergadering 6

Variabele		|Inhoud
---			|---
**Datum:**              |Donderdag 28 november 2013
**Locatie:**            |ig lokaal
**Begin:**              |16u00
**Einde:**              |
**Aanwezigen:**         |
**Secretaris:**         |Youssef Boudiba

## TODO-list vorige vergadering (? min)
* front-end: mock-up aanpassen in functie van iteratie 1 via bv. lucid-chart (dinsdag 26 november 8u).
* front-end: ui-implementatie bespreken.
* Nils, Anders (en Lars): requirments omzetten in milestones (beperken tot eerste iteratie, dinsdag 26 november 10u).
* Nils en Adriaan: databasedesign aanpassen.


## 1. Aanstelling nieuwe secretaris (Lars & Youssef) (10 min)
De functie van secretaris is terug vacant. Youssef geeft meer uitleg hieromtrent.

## 2. Bespreking aangemaakte issues Github (Lars) (15 min.)
Bespreking en concreter schetsen van de (door Nils) aangemaakte issues.


## 3. Bespreking algemene voortgang (Lars) (25 min.)
- Clojure voortgang
- Welke IDE

## Mededelingen

## TODO-list


