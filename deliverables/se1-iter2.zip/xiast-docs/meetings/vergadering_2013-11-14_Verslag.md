# Verslag vergadering 5
Variabele		|Inhoud
---			|---
**Datum:**              |Donderdag 14 november 2013
**Locatie:**            |IG lokaal
**Begin:**              |17u15
**Einde:**              |18u40
**Aanwezigen:**         |Youssef Boudiba, Kwinten Pardon, Nils Van Geele, Adriaan Leijnse, Lars Van Holsbeeke
**Secretaris:**         |Youssef Boudiba


## 0. TODO-list vorige vergadering
* Lars: flows/pijlen van het structuur graf verklaren (best eerst een tekst schrijven over de verschillende functie en relaties tussen die functies).
* Youssef: Eerste versie STD en SQAP tegen volgende vergadering.
*   STD is af, SQAP moet nog geschreven worden.
* Iedereen: onder puntje 4.3 (SPMP) past iedereen zijn verantwoordelijkhed aan.
*   Nils: algemenen servermanager
* Kwinten: SDP.
* Nils: SCMP vervolledigen.
* Adriaan: definieert api’s.
*   Nog niet af.
* Anders,Youssef & Kwinten: Front-end(UI).
*   In orde.
* Lars & Adriaan: definieren eerste iteratie.
*   In orde.


## 1. Bespreking feedback SPMP (30 min)
### 1.1. Bepaling Risico's
* Externe risico's

  Slechte communicatie/afstemming met de klant.

* Technische risico's

  Taal: kennis clojure, javascript, html5 (algemeen: kennis vand verschillende tools en talen).
  Server: wilma (1 keer om de 6maanden), stroomuitval
  Remote repository gitHub kan ook uit vallen.
  
* 'echte' risico's
  
  Conflicten tussen teamleden.
  Verkeerde interpretatie van de requirments.

### 1.2. Meer uitleg genereren betreffende spiraalmodel
* best een betere afbeelding zoeken
* 

### 1.3. Activiteiten definieren

* Authenticatiesysteem: front-end (3 weken)
* DB-access: back-end (2 weken)
* Imlementatie querri API: back-end (1 week)
* DB-design: back-end (afhankelijk van datadump, 2 weken)
* Documenatation maintainance: iedereen (constant)

## 2. PDF generatie uit markdown

  Configuration manager heeft de nodige tools megedeeld om pdf te kunnen genereren uit markdown.
  
## 3. Conflict STD
  In orde.

## 4. TODO-list

* Lars: Meer uitleg bij model
* Youssef, Kwinten en Anders: HTML5 en javascript (voor de 2de iteratie, kan nog veranderen: Coffeescript) 
* Front-end + Adriaan: vergadering voor clojure.
* Adriaan: verzamelt clojure tutorials.
* Iedereen: Clojure leren (vanuit java) 
* Back-end: analyseren datadump zodra ze beschikbaar is.
* Front-end: mock-up aanpassen in functie van iteratie 1.

## Naderende Deadlines

Datum       | Onderwerp
---         |---
15/11/2013  |Eerste versie documenten!
