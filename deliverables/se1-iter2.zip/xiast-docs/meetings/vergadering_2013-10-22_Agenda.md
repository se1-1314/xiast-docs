Vergadering II - Agenda

1. TODO-List vorige vergadering (10 min)

    1. **Lars:** bezorgt iedereen zijn GSM-nummer.

    2. **Lars:** gaat de verwarring tussen programmabeheerder, programmamanager en implementatie leader ontwarren.

    3. **Anders:** zorgt voor het logo van het project.

    4. **Anders:** deelt zijn suggesties op in iteraties.

    5. **Youssef,Lars & Anders:** volgen de eenvoudige tutorials op[ http://try.github.io/levels/1/challenges/1](http://try.github.io/levels/1/challenges/1) om  aan de slag te kunnen gaan met gitHub.

    6. **iedereen:** denken na over hun mogelijke back-up functie.

2. Goedkeuring  verslag vorige vergadering (2 min)

3. Bepalen taal vergaderingen en verslagen (5 min)

4. Toewijzing Back-Up functies (15 min)

5. Bespreken van requirements (45 min)

6. Vastleggen doelstellingen iteratie 1 (20 min)

7. Uitleg over de workflow - Nils (15 min)

8. Verplaatsing vergadermoment week 7 - Lars (5 min)

    7. maandag 28/10/2013 - 13u -IG

9. Mededelingen

    8. Aankomende Deadlines

		

<table>
  <tr>
    <td>Datum</td>
    <td>Doel</td>
  </tr>
  <tr>
    <td>04/11/2013</td>
    <td>SPMP inleveren (Lars)</td>
  </tr>
  <tr>
    <td>15/11/2013</td>
    <td>eerste versie documenten</td>
  </tr>
</table>


