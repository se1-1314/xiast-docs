(ns xiast.core-test
  (:require [clojure.test :refer :all]
            [xiast.core :refer :all]))

(deftest a-test
  (testing "FIXME, I do nothing."
    (is (= 1 1))))
