# Verslag vergadering 2 

Variabele	|Inhoud
---		|---
**Datum:**	|Dinsdag 22 oktober 2013
**Locatie:**	|F4, Campus VUB Etterbeek
**Begin:**	|15u
**Einde:** 	|16u40
**Aanwezigen:**	|Adriaan Leijnse, Nils Van Geele, Lars Van Holsbeke, Anders Deliens, Kwinten Pardon, Youssef Boudiba
**Secretaris:**	|Youssef Boudiba, Lars Van Holsbeke

## TODO-List vorige vergadering (10 min)

Er wordt voortaan, bij het begin van elke vergadering, nagegaan of de TODO-list van de vorige vergadering in orde is.

    1. **Lars:** bezorgt iedereen zijn GSM-nummer.

        1. in orde

    2. **Lars:** gaat de verwarring tussen programmabeheerder, programmamanager en implementatie leader ontwarren.

        2. in orde

    3. **Anders:** zorgt voor het logo van het project.

        3. Anders heeft  via een contact 2 logo’s ontvangen.

        4. idem voor Nils

    4. **Anders:** deelt zijn suggesties op in iteraties.

        5. Bijna af

    5. **Youssef,Lars & Anders:** volgen de eenvoudige tutorials op[ http://try.github.io/levels/1/challenges/1](http://try.github.io/levels/1/challenges/1) om  aan de slag te kunnen gaan met gitHub.

        6. In orde

    6. **iedereen:** denken na over hun mogelijke back-up functie.

        7. wordt gedurende dit vergadering vastgelegd

2. Goedkeuring  verslag vorige vergadering (2 min)

    7. Verslag is in orde

    8. Vanaf volgende vergadering worden de verslagen op gitHub gemaakt.

3. Bepalen taal vergaderingen en verslagen (5 min)

    9. Verslagen van vergaderingen worden in het Nederlands geschreven

    10. Alle andere documenten(documentatie,...) worden in het Engels geschreven.

4. Toewijzing Back-Up functies (15 min)

    11. **Anders**:	Project Manager

    12. **Lars:		**Configuration Manager

    13. **Adriaan:	**Requirements Management leader

    14. **Kwinten:	**Quality Assurance Leader 

    15. **Nils:		**Design Leader 

    16. **Youssef:	**Code base manager

**Opmerking:** 

Youssef is nu de nieuwe Quality Assurance Leader.

Kwinten is nu de Code base manager, implementation leader vervalt.

5. Bespreken van requirements (45 min)

    17. Anders werkt verder op het requirmentsdocument dat Adriaan reeds begonnen was.

    18. Ragnhild heeft de onduidelijkheden i.v.m. programma-manager <-> programma-beheerder aangepast. We kunnen dit best herlezen 

6. Vastleggen doelstellingen iteratie 1 (20 min)

    19. **Maken van een (manuele) scheduler**

        8. Hoe roosters voorstellen (datatype) erachter, ZONDER CONSTRAINTS: 

            1. van dan tot dan

            2. etc.

        9. Databaseformaat: ORM: constraints vastleggen

        10. mensen die zich hier mee bezighouden

            3. Design manager (hoofdpersoon)

            4. DB-manager

            5. Requirements manager (fit voorstelling in het geheel van het project)

    20. **Inlogsysteem(Basis)**

        11. 2 types:

            6. lezer - gebruiker

            7. schrijver - Superuser

        12. Nadenken over het rechtensysteem hoe authentificeren

        13. mensen die zich hier mee bezighouden: Lars

    21. **UI**

        14. mensen die zich hiermee bezig houden

            8. Project Manager

            9. Quality manager

            10. Implementation Manager

7. Uitleg over de workflow - Nils (15 min)

Vermits Nils ervaring heeft met de DVCS git, heeft hij de basis van git en de structuur die wij zullen hanteren op de hostingsite gitHub kort en bondig uitgelegd. Belangrijke punten waren: 

    22. We maken gebruik van 2 repositories: één voor de code zelf, de andere dient om de documenten(verslagen,...) op te slagen.

    23. Bugs en andere problemen gaan we op gitHub beschouwen als issues. De issues worden over de groep verdeeld. 

    24. Pull requests en conflicten.

8. TO DO List

* **Anders: ** werkt requirements verder uit.

* **Adriaan, Anders, Nils:** werken een voorstelling voor lessenrooster uit.

* **Nils: **denkt na over een inlogsysteem met (momenteel) nog 2 types rechten.

* **Kwinten, Youssef, Lars: **denken (visueel) na over GUI.

* **Iedereen:** denkt na over welke taal we kunnen gebruiken voor implementatie.

9. Verplaatsing vergadermoment week 7 - Lars (5 min)

* **_Locatie:_*** 	infogroep, Campus VUB Etterbeek*

* **datum:** 	Maandag 28 oktober 2013

* **tijd:** 		13u

10. Mededelingen

    25. Aankomende Deadlines	

<table>
  <tr>
    <td>Datum</td>
    <td>Doel</td>
  </tr>
  <tr>
    <td>04/11/2013</td>
    <td>SPMP inleveren (Lars)</td>
  </tr>
  <tr>
    <td>15/11/2013</td>
    <td>eerste versie documenten</td>
  </tr>
</table>


