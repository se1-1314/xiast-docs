xiast
=====

Xiast is a scheduling tool

# Configuration
Copy `xiast.conf.example` to `xiast.conf` and fill in all information.
When using sqlite as database back-end, only `:database` is required
and needs to contain the location of the sqlite file.
