# Agenda vergadering 8

Variabele				|Inhoud
---			    		|---
**Datum:**              |Maandag 9 december 2013
**Locatie:**            |1E08
**Begin:**              |12u20
**Einde:**              |
**Aanwezigen:**         |
**Secretaris:**         |Nils Van Geele

## TODO-list vorige vergadering (15 min)
* Kwinten: geeft aan front-end team uitleg over hoe content te plaatsen, templates aan te maken, templates aan te passen, ...
* Iedereen: Clojure Style Guide lezen
* Iedereen: Iedereen leest de slides van het HOC over zijn domein
* Iedereen: Grondig nalezen en updaten van alle documenten tegen 8/12/2013
* Nils: Nog een laatste keer polsen naar logo
* Anders(?): LaTeX template (naar Lars mailen voor informatie)

1. Bespreking voortgang (Lars) (20 min)
  * Code
    * Werkt alles?
    * Reeds klaar om in te dienen of dienen er nog laatste wijzigingen aangebracht te worden
    * Wie dient in, en onder welke vorm?
  
  * Documenten
    * Alles documenten klaar?
    * Welke documenten dienen nog samengevoegd te worden?
    


## Mededelingen
- Reminder: vergeet jullie documenten niet volledig af te werken

## TODO-list


## Volgende vergadering
* Locatie: IG
* Datum: 9 december 2013
* Tijd: 12u
