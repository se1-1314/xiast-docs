# Verslag vergadering 11

Variabele				  |Inhoud
---			    		  |---
**Datum:**        |Donderdag 6 maart 2014
**Locatie:**      |E1.08
**Begin:**        |16u05
**Einde:**        |
**Aanwezigen:**   |
**Secretaris:**   |Nils Van Geele


# TODO-list vorige vergadering
- Meeting op IG later op donderdag om nieuwe issues aan te maken
  - Is gebeurd
- Anders en Youssef: nemen de tutorial van 4Clojure tegen vrijdag (= dag na vergadering!) om de nodige basiskennis m.b.t. Clojure te vergaren => API kunnen gebruiken.
  - Is gebeurd


# 1. Bespreking ingeleverd werk + opmerkingen Jens -> in hoeverre zijn deze in rekening gebracht (Lars, 20 min)
## Vragen & opmerkingen Jens
* Is de datadump al helemaal verteerd?
  * Deels.
* Is er al nagedacht over de scheduler?
  * Ja. Nog geen implementatie, maar wel ideeen over hoe de datastructuur er bij helpt en integratie
  * Opmerking: Iteratief inbouwen in de applicatie. Gedachtegangen en discussies erover bijhouden.
* De demo moet beter, en er moet eigenlijk gesproken worden over de demo. Focussen op het feit dat er een goede demo moet zijn die laat zien wat er allemaal afgewerkt is. Werk vanaf nu dus in functie van demo; documenten fixen, maar coderen is voornaamste zaak nu.
* Blijven coderen na deadline naar demo toe.

# 2. Bespreking: wat nog te doen voor de demo (Lars, 30 min)
Wat moet er nog allemaal gebeuren om iets werkend en functioneel te laten zien.

- Wat kan/is er al
  - Front-end code om schedules te displayen
  - Back-end code om rooms, courses en course-activities is er
- Wat moet er nog gedaan worden
  - API uitbreiden om schedules op te vragen
  - API uitbreiden om programs aan te maken
  - Authentication uitbreiden om na te gaan of gebruiker program manager, titular, ... is
  - Front-end pagina voor program manager, moet niet per se werken maar moet er zijn (Kwinten)
  - Front-end pagina voor titular (Youssef)

# 3. Presentatie Iteratie 2 (Lars, 10 min)
Wie gaat presenteren en waar moet er tijdens die presentatie op gefocust worden.

Kwinten en Nils gaan presenteren. Lars gaat aan presentatie sleutelen.

# Mededelingen
* Privégesprek met Kwinten en Adriaan


# DEADLINES:
 * Woensdag 12/03/2014 - Presentatie

# TODO-list
- Zie punt 2

# Volgende Vergadering
Moet nog afgesproken worden, maar zal waarschijnlijk vrijdag 14 maart doorgaan.

