# Agenda vergadering 8

Variabele				|Inhoud
---			    		|---
**Datum:**              |Maandag 9 december 2013
**Locatie:**            |1E08
**Begin:**              |12u20
**Einde:**              |12u57
**Aanwezigen:**         |Iedereen
**Secretaris:**         |Nils Van Geele

## TODO-list vorige vergadering (15 min)
* Kwinten: geeft aan front-end team uitleg over hoe content te plaatsen, templates aan te maken, templates aan te passen, ...
** Gebeurd
* Iedereen: Clojure Style Guide lezen
** Niet gebeurd
* Iedereen: Iedereen leest de slides van het HOC over zijn domein
** Gebeurd
* Iedereen: Grondig nalezen en updaten van alle documenten tegen 8/12/2013
** Half gebeurd
* Nils: Nog een laatste keer polsen naar logo
** Persoon had geen tijd meer om logo te maken
* Anders(?): LaTeX template (naar Lars mailen voor informatie)
** Wordt aan gewerkt

## Bespreking voortgang (Lars) (20 min)
  * Code
    * Werkt alles?
    ** Neen, er moet nog vanalle templates gemaakt worden. Maar Kwinten kan er de komende dagen nog aan werken.
    * Reeds klaar om in te dienen of dienen er nog laatste wijzigingen aangebracht te worden
    ** Neen aangezien er nog aan gewerkt moet worden (oppoetsen, wat extra dingen toevoegen, ...)
    * Wie dient in, en onder welke vorm?
    ** Donderdag wordt er nog samengekomen dus er wordt dan naar gekeken.
  
  * Documenten
    * Alles documenten klaar?
    ** Neen; SPMP moet nog worden afgewerkt, SDP en SDD
    * Welke documenten dienen nog samengevoegd te worden?
    ** Alleen SCMP en SPMP moeten woren samengevoegd (donderdag)
    

## Vragen
- Anders gaat na de examens eens met Jens en Adriaan samenzitten i.v.m. commentaar op de SRS. Maar weet iemand nog design constraints, requirements of dingen voor bij 3.4, 3.5 en 3.6 die er in zouden moeten staan? Mail naar Anders.

## Mededelingen
- Donderdag 12/12 vanaf 16u: Samen komen op IG om iteratie 1 af te werken

## TODO-list
- Youssef: maakt about pagina
- Kwinten: templates maken
- Iedereen: documenten af tegen woensdag

## Volgende vergadering
* Locatie: IG
* Datum: volgend semester (zal nog rondgemaild worden)
* Tijd: 
