# Agenda vergadering 9

Variabele				  |Inhoud
---			    		  |---
**Datum:**        |Donderdag 27 februari 2014
**Locatie:**      |10F
**Begin:**        |12u05
**Einde:**        |
**Aanwezigen:**   |
**Secretaris:**   |Nils Van Geele


# TODO-list vorige vergadering

* Iedereen: Documenten aanpassen, uren die je werkt opschrijven
* Youssef: Clojure en JavaScript oppoetsen
* Adriaan: API wat verder uitwerken, opzoeken informatie voor scheduler
* Lars: Clojure oppoetsen, samen met Nils database designen
* Kwinten: Front-end code nog eens doornemen, oppoetsen
* Anders: Clojure en JavaScript oppoetsen
* Nils: samen met Lars database designen

# 1. Overlopen Issues en Milestones (Lars, 50 min)
Alvorens op volgende kracht te beginnen coden dient er eerst 'richting' te worden gegeven: we overlopen de reeds bestaande milestones/issues en vullen deze aan voor wat betreft deze iteratie (op basis van het opgestelde lijstje van vorige vergadering). Elke issue zal vervolgens worden toegewezen aan een teamlid die ervoor zorgt dat deze issue wordt opgelost tijdens de hackathon van vrijdagavond.


# 2. Hackathon vrijdagavond (Lars, 10 min)
Nu vrijdag: vanaf 15u tot gedaan: coden. Iedereen verplicht aanwezig!

# 3. Discussie Design (Adriaan, 20 min)
Bespreking API, hoe gebruiken, achterliggende werking, etc.


# Mededelingen

Deadlines:
 * **!** Dinsdag 04/03/2014 - Opleveren CODE en DOCUMENTEN **!**
 * Woensdag 12/03/2014 - Presentatie

# TODO-list
- Anders en Youssef: nemen de tutorial van 4Clojure tegen vrijdag (= dag na vergadering!) om de nodige basiskennis m.b.t. Clojure te vergaren => API kunnen gebruiken.

# Volgende Vergadering
Donderdag 5 maart, zelfde plaats, zelfde uur
