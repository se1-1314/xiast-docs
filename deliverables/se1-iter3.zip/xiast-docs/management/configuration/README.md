Configuration management leader
===============================

Nils
