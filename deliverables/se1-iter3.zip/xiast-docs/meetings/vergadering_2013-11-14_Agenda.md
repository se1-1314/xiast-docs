# Agenda vergadering 5
Variabele		|Inhoud
---			|---
**Datum:**              |Donderdag 14 november 2013
**Locatie:**            |IG lokaal
**Begin:**              |18u
**Einde:**              |
**Aanwezigen:**         |Youssef Boudiba, Kwinten Pardon, Nils Van Geele, Adriaan Leijnse, Lars Van Holsbeeke, Anders Deliens
**Secretaris:**         |Youssef Boudiba


## 0. TODO-list vorige vergadering
* Lars: flows/pijlen van het structuur graf verklaren (best eerst een tekst schrijven over de verschillende functie en relaties tussen die functies).
* Youssef: Eerste versie STD en SQAP tegen volgende vergadering.
* Iedereen: onder puntje 4.3 (SPMP) past iedereen zijn verantwoordelijkhed aan.
* Kwinten: SDP.
* Nils: SCMP vervolledigen.
* Adriaan: definieert api’s.
* Anders,Youssef & Kwinten: Front-end(UI).
* Lars & Adriaan: definieren eerste iteratie.


## 1. Bespreking feedback SPMP (30 min)
### 1.1. Bepaling Risico's
* Externe risico's
* Technische risico's
* 'echte' risico's

### 1.2. Meer uitleg genereren betreffende spiraalmodel
* best een betere afbeelding zoeken

## 2. PDF generatie uit markdown

## 3. Conflict STD



## Naderende Deadlines

Datum       | Onderwerp
---         |---
15/11/2013  |Eerste versie documenten!
