# Agenda vergadering 14

Variabele				  |Inhoud
---			    		  |---
**Datum:**        |Vrijdag 04 april 2014
**Locatie:**      |10F
**Begin:**        |11u
**Einde:**        |
**Aanwezigen:**   |
**Secretaris:**   |Nils Van Geele


# TODO-list vorige vergadering (30 min)

- Lars stuurt time tracking mail
- Lars contacteert Jens voor vergadering

# 1. Opvolging voortgang/ Algemene TODO list (Lars, 30-40 min)

- EER model van database maken voor documentatie (liefst automatisch) **Nils**
- Security (wrappers voor API) **Nils**
- Back-end heeft al voorzieningen voor courses, programma's, rooms, ...
- Beter design document
  - **Adriaan** werkt eraan; modellen, flow-charts, ...
- Meer documentatie
  - Zoveel mogelijk docstrings in code
- Testing
  - Meer test-driven development; vooral voor scheduler
  - Regression tests voor bugs
- Training
  - Best om gewoon te werken, hulp vragen of zoeken bij problemen
  - Samensmelting met implementatie
- Appcache bug oplossen **Kwinten**
- VUB link bug oplossen **Kwinten**
- Translations in navbar **Adriaan**
- URL probleem **Adriaan**
- Koppeling front-end <> back-end
  - Student Page **Kwinten**
  - Opvolging front-end members: kennis i.v.m. de architectuur van de applicatie bijschaven (Lars)

# 2. Overlopen documenten met Jens (Lars, 15 min)
- STD
- SDD


# Mededelingen
- Codesessies, telkens vanaf 11u: (Lars)
  - Donderdag 10 april
  - Vrijdag 11 april (nachtsessie)
  - Maandag 14 april
--> Straks met een beperkt aantal mensen storyboard met tussenliggende deadlines opstellen: wanneer moet wat 


# DEADLINES:
- !15 april: deadline iteratie 3

# TODO-list


# Volgende Vergadering

