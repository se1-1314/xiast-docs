# Agenda Vergadering 12

Variabele				  |Inhoud
---			    		  |---
**Datum:**        |Vrijdag 14 maart 2014
**Locatie:**      |E1.08
**Begin:**        |15u
**Einde:**        |
**Aanwezigen:**   |
**Secretaris:**   |Nils Van Geele


# TODO-list vorige vergadering
- Wat kan/is er al
  - Front-end code om schedules te displayen
  - Back-end code om rooms, courses en course-activities is er
- Wat moet er nog gedaan worden
  - API uitbreiden om schedules op te vragen
  - API uitbreiden om programs aan te maken
  - Authentication uitbreiden om na te gaan of gebruiker program manager, titular, ... is
  - Front-end pagina voor program manager, moet niet per se werken maar moet er zijn (Kwinten)
  - Front-end pagina voor titular (Youssef)


# 1. Evaluatie presentatie/iteratie 2 + vooruitblik & planning iteratie 3 (Lars, 1u15)
- Bespreking commentaar tijdens afgelopen presentatie (ik heb nota's genomen). Belangrijkste punten
  - Testplan!
  - Dashboard! (meer high-level gaan dan de issue tracker)
  - SDD!
  - **!**TRAINING **!**
- Evaluatie iteratie 2: wat liep er verkeerd?
  - Chronologisch overzicht op stellen (voor iter2), probleempunten erop vinden: wat was de oorzaak van de vertraging, waar werden de verkeerde beslissingen genomen,...

- Planning en doelstellingen iteratie 3 a.d.h.v. SPMP vastleggen
  - Tijdschattingen maken
  - Samenkomsten tijdens paasvakantie vastleggen!
  
- (groeps/code) Problemen/Onduidelijkheden vastleggen en oplossen + naar de toekomst toe: hoe kunnen we deze in het vervolg het efficiëntste oplossen (en lieft zelfs voorkomen!)

- **Trainingsschema** vastleggen: tegen wanneer moet wat gekend zijn (!zonder excuses)

- Eerste codingsessie




# Mededelingen
* Privégesprek met Kwinten


# DEADLINES:


# TODO-list


# Volgende Vergadering


