Vergadering I (15/10/2013): Agenda

Wie is secretaris en wil het verslag van deze vergadering opmaken

1. Guidelines, tools en communication procedures opstellen: Policies (25 min)

    1. Communicatie

    2. Informatie delen

    3. Regels bij het bewerken van documenten, mergen van documenten

    4. Op welke manier bepalen we eventuele meetings buiten de het vaste meetingmoment

        1. Alles via projectleider? (Alles van logistiek)

    5. Openbaar maken van documenten

    6. etc.?

2. Functies bepalen:(40 min)

    7. Projectmanager - Lars

        2. SPMP

    8. Configurationmanager - Nils

        3. DB-mangement

        4. SCMP

    9. Quality assurance leader - Kwinten

        5. SQAP, STP

        6. test-leader

    10. Requirements management leader - Anders

        7. SRS

    11. Design leader - Adriaan

        8. SDD

    12. Implementation leader - Youssef

        9. code baseWebmaster

3. Naam bepalen

    13. **casy** (creating a schedule for you)

    14. **xiast **(xiast is a scheduling tool) <<<<

    15. **stom **(scheduling tool op maat)

    16. **sandy **(scheduling and displaying yours)

    17. **cinar** (cali isn’t a rival)

    18. right on time

    19. gregor...dinges

    20. Cali-mero <<

    21. Skedu.lr

    22. My Schedule

Beslissing: XIAST

4. Logo bepalen

	Anders vraagt eens na bij zijn vrienden

	Nils betaalt een pint of twee aan zijn maat.

5. TODO list

VOLGENDE WEEK VERGADERING OM 15:00

