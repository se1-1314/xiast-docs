# Verslag vergadering 6

Variabele		|Inhoud
---			|---
**Datum:**              |Donderdag 21 november 2013
**Locatie:**            |ig lokaal
**Begin:**              |18u30
**Einde:**              |
**Aanwezigen:**         |
**Secretaris:**         |Youssef Boudiba

## TODO-list vorige vergadering (? min)

* Lars: Meer uitleg bij model
  In orde
* Front-end + Adriaan: vergadering voor clojure.
  In orde
* Adriaan: verzamelt clojure tutorials.
  Ok
* Iedereen: Clojure leren (vanuit java) 
  Bijna iedereen.
* Back-end: analyseren datadump zodra ze beschikbaar is.
* Front-end: mock-up aanpassen in functie van iteratie 1.


## 1. Bespreking en analyze datadump (Lars) (10 min)

Bespreken en al dan niet grafisch analyseren van de datadump, gekregen op 18/11/2013. Verbanden leggen tussen de verschillende spreadsheets. Nadenken over een mogelijk implementatiemodel.


##2. Front-end: Clojure Training: Korte bespreking (Lars) (10 min)
Nabespreking Clojure training video's met team "front-end": checken of dat alles duidelijk was en dat iedereen alles begrepen heeft.

##3. Bespreking GANTT-Chart (Lars) (60 min)
Evalueren of de voorgestelde planning realistisch is voor iedereen, waar nodig ook aanvullen. Een deel van de planning zal spijtig genoeg achterhaald zijn als gevolg van het laat beschikbaar zijn van deze chart.

##4. Informatie uit de theorielessen (Lars) (5 min)
Ik zou graag hebben dat iedereen (voor wie dit reeds mogelijk is) nog eens aandachtig de slides uit de theorielessen, betreffende zijn verantwoordelijkheden, doorneemt. Hier zit behoorlijk wat informatie in over wat men precies verwacht van onder andere je documentatie. vb. voor de SPMP: hoe doe ik een kostenschatting -> gebruik het COCOMO-model. Voor ons persoonlijk is dat waarschijnlijk niet echt realistisch, aangezien wij 'oneindig' budget hebben (met uitzondering van tijd); maar weet dat het hier nog steeds een soort simulatie van de (zo goed als) echte wereld betreft en onze klant dit soort zaken zeker zal kunnen appreciëren.

###4.1 SPMP
* aanmaken van een kostenraming
* aanmaken van een network-activity diagram => kritisch pad weergeven
* aanmaken van een software product breakdown chart


##5. Bespreking feedback betreffende de ingeleverde documenten (Lars) (20 min)
Analyse feedback <-> ingeleverde documenten. Bespreken: wat kan beter, wat moet nog toegevoegd/verwijderd worden, lay-out, etc.

###5.1 SPMP

Risks: metriek duidelijk uitleggen (hoe leg je dat allemaal vast).

###5.2 SRS

###5.3 STD


##6. Logo (Lars) (5 min)
Zonder al te veel druk, maar hoever staat het met het ontwerp van ons logo door externen? In geval dat het nogal moeilijk zou liggen, zouden we zelf geen simpel maar smaakvol logo kunnen ontwerpen?

##7. Requirements op GitHub (Nils) (5 min)
De requirements zouden moeten omgezet worden naar milestones en issues.
Een deadline wordt niet als een milestone beschouwd.

##8. Implementatie: startschot (Lars) (10 min)
Vanaf volgende week hebben we nog exact 2 weken tot onze eerste milestone. In hoeverre zijn beide teams klaar om te beginnen coderen? Wat hebben ze nog nodig van informatie, documentatie, plannen, designs, modellen, etc. opdat het implementeren zou kunnen aanvangen?


## Mededelingen
* Er is een milestone gemaakt voor het einde van de eerste iteratie. Deze werd geplaatst op zondag 8/12/2013. Lees de beschrijving.

## TODO-list
* front-end: mock-up aanpassen in functie van iteratie 1 via bv. lucid-chart (dinsdag 26 november 8u).
* front-end: ui-implementatie bespreken.
* Nils, Anders (en Lars): requirments omzetten in milestones (beperken tot eerste iteratie, dinsdag 26 november 10u).
* Nils en Adriaan: databasedesign aanpassen.

## Volgende vergadering

* Datum: 28 november 2013
* Locatie: IG
* Tijd: 16u

